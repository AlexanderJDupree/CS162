/*******************************************************************************
* File: courseDriver.cpp
*
* Description: Driver program tests all constructors and methods for course class
*
* Author: Alexander DuPree
*
* Compiler: GNU GCC 5.4.0
*
* Date: 2018 - 05 - 24
*******************************************************************************/

#include <iostream>
#include <vector>
#include <numeric>
#include <cstring>
#include <cassert>
#include "course.h"

#define LOG(x) std::cout << '\n' << x << std::endl;

int main()
{
    const char* COURSE = "Calculus 2";
    const char* IDENT = "MTH252";

    // Use of iterator constructor because c++98 does not allow initializer
    // list construction of vectors 
    const int grades[] = {25, 35, 45, 90, 95};
    const Gradebook GRADES(grades, grades + sizeof(grades) / sizeof(int));

    // Test course constructors
    Course course1;
    Course course2(COURSE, IDENT, GRADES);

    assert(*course1.name() == '\0');
    assert(*course1.ID() == '\0');
    assert(course1.grades().empty() == true);

    LOG("Default constructors PASS");

    assert(strcmp(course2.name(), COURSE) == 0);
    assert(strcmp(course2.ID(), IDENT) == 0);
    assert(course2.grades() == GRADES);

    LOG("Overloaded Constructors PASS");
    
    // Test copy constructor and assignment operator
    course1 = course2;

    assert(strcmp(course1.name(), course2.name()) == 0);
    assert(strcmp(course1.ID(), course2.ID()) == 0);
    assert(course1.grades() == course2.grades());

    LOG ("Copy constructor and Assignment operator PASS");

    // Test mutators
    course1.name("Computer Science II")->ID("CS162")->grades(Gradebook(4, 100));

    assert(strcmp(course1.name(), "Computer Science II") == 0);
    assert(strcmp(course1.ID(), "CS162") == 0);
    assert(course1.grades() == Gradebook(4,100));

    LOG("Mutators PASS");

    // Test friend functions
    assert(findHighest(course2) == 95);
    
    double sum = std::accumulate(GRADES.begin(), GRADES.end(), 0.0);
    double average = sum / GRADES.size();

    assert(findMean(course2) == average);

    LOG("Friend functions PASS");


    return 0;
}