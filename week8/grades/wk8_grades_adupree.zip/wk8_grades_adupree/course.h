/*******************************************************************************
* Class: Course

* Description: Course represents a specific academic course and contains 
               inspectors, mutators, and constructors for modifying the values
               associated with the courses name, identifier and grades

* Attributes and Methods:

public:

    - Constructors
    Course();
    // Precondition: 
    // Postcondition: Instantiates a default Course object with null values

    Course(const char* course, const char* ident, const Gradebook& grades);
    // Precondition: 
    // Postcondition: Instantiates an explicit Course object with values 
                      set to the arguments

    Course(const Course& origin);
    // Precondition: A valid Course object reference
    // Postcondition: The values of the origins members are copied onto the new
                      Course object

    - Destructor
    ~Course();
    // Postcondition: Frees up memory associated with members 

    - Inspectors
    const char* name() const; 
    // Postcondition: Returns a const pointer to courseName member

    const char* ID() const;
    // Postcondition: Return a const pointer to courseID member

    const Gradebook& grades() const;
    // Postcondition: Returns a const reference to courseGrades member

    - Mutators
    Course* name(const char* name);
    // Precondition: A valid pointer to a string literal
    // Postcondition: Frees memory associated with courseName member, copies
                      the values of name argument onto a new block of memory
    Course* ID(const char* ident);
    // Precondition: A valid pointer to a string literal
    // Postcondition:  Frees memory associated with courseID member, copies
                       the values of ident argument onto a new memory block

    Course* grades(const Gradebook& courseGrades);
    // Postcondition: Copies the courseGrades arguments values onto the 
                      member courseGrades

    - Operator Overloads
    Course& operator=(Course course);
    // Precondition: A Course object copy
    // Postcondition: Uses the copy and swap idiom for safe copy assignment of 
                      a course object

    friend void swap(Course& newCourse, Course& oldCourse) throw();
    // Postcondition: reassigns ownership of pointers associated with course 
                      objects

    - Friend functions
    friend unsigned int findHighest(const Course& course);
    // Precondition: a valid course object reference
    // Postcondition: returns the highest value in the course's grades member

    friend double findMean(const Course& course);
    // Precondition: a valid course object reference
    // Postcondition: returns the average of the courses' grades member

private:

    char* courseName - Represents the name of the course
    char* courseID- Representes the Identifier for a course
    Gradebook courseGrades - Contains all the grades associated with a course

* Author: Alexander DuPree
 
* Compiler: GNU GCC 5.4.0

* Date: 2018 - 05 - 24
*******************************************************************************/

#ifndef Course_H
#define Course_H

#include <vector>

typedef std::vector<unsigned int> Gradebook;

class Course
{
public:
    // Constructors
    Course();

    Course(const char* course, const char* ident, const Gradebook& grades);

    Course(const Course& origin);

    // Destructor
    ~Course();

    // Inspectors
    const char* name() const; 
    const char* ID() const;
    const Gradebook& grades() const;

    // Mutators
    Course* name(const char* name);
    Course* ID(const char* ident);
    Course* grades(const Gradebook& courseGrades);

    // Operator Overloads
    Course& operator=(Course course);

    // Swap functionality for assignment operator
    friend void swap(Course& newCourse, Course& oldCourse) throw();

    // Friend functions
    friend unsigned int findHighest(const Course& course);
    friend double findMean(const Course& course);

private:

    char* courseName;
    char* courseID;
    Gradebook courseGrades;

};

#endif // Course_H
