/*******************************************************************************
* File: point.h

* Description: Point class represents a Cartesian Coordinate. Provides methods for
               accessing, mutating, and comparing point objects and its members

* Attributes and Methods:
public:
    - Constructors
    Point();
    // Instantiates a point object at the point (0,0)

    Point(const int& x, const int& y);
    // Instantiates a point object at the location (x,y)

    - Inspectors
    const int& getX() const;
    // Returns a const reference to the member x

    const int& getY() const;
    // Returns a const reference to the member y

    - Mutators
    Point* setX(int x);
    // Sets the value of member x to the argument x. Returns a pointer to this
    // object.

    Point* setY(int y);
    // Sets the value of member y to the argument y. Returns a pointer to this
    // object

    - Operator Overloads
    bool operator==(const Point& point) const;
    // Returns true if the point's x,y members are equal to this points members

    bool operator!=(const Point& point) const;
    // Returns the logical NOT of the == operators comparison

private:

    int x; - Represents the x coordinate of a Cartesian point
    int y; - Represents the y coordinate of a Cartesian point


* Author: Alexander DuPree

* Compiler: GNU GCC 5.4.0

* Date: 2018 - 05 - 17
*******************************************************************************/

#ifndef POINT_H
#define POINT_H

class Point
{
public:
    // Default Constructor
    Point();

    // Overloaded Constructor
    Point(const int& x, const int& y);

    // Inspectors
    const int& getX() const;
    const int& getY() const;

    // Mutators
    Point* setX(int x);
    Point* setY(int y);

    // Operator Overloads
    bool operator==(const Point& point) const;
    bool operator!=(const Point& point) const;

private:

    int x;
    int y;

};

#endif // POINT_H
