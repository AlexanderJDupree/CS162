/*******************************************************************************
* File: line.h

* Description: Line class represents the line drawn between two point objects.
               Provides methods for accessing and mutating its point members as
               well as member functions that can determine the slope and length
               of a line.

* Attributes and Methods:
public:
    -Constructors
    Line();
    //Instantiates a line between the points (0,0) and (0,0)

    Line(const Point& point1, const Point& point2);
    // Instantiates a line between the points point1 and point2

    Line(const int& x1, const int& y1, const int& x2, const int& y2);
    // Constructs two point objects with the points (x1,y1) and (x2, y2) and
    // Instantiates a line between those two points

    - Inspectors
    const Point& point1() const;
    // Returns a const reference to point1

    const Point& point2() const;
    // Returns a const reference to point2

    - Mutators
    Line* point1(const Point& point);
    // Sets the Lines point1 member to the value of point argument. Returns a
    // pointer to this object

    Line* point2(const Point& point);
    // Sets the Lines point2 member to the value of point argument. Returns
    // a pointer to this object

    Line* point1(const int& x, const int& y);
    // Sets the lines point1 members X and Y to the provided arguments x, y.
    // Returns a pointer to this object

    Line* point2(const int& x, const int& y);
    // Sets the lines point2 members X and Y to the provided arguments x,y.
    // Returns a pointer to this object

    - Member functions
    double slope() const;
    // Utilizes the slope formula to determine the slope of the line. In the
    // case of a divide by zero error, the function returns the UNDEFINED
    // constant

    double length() const;
    // Uses pythagoras theorum to return the length of the line connecting
    // the two points


    - Operator Overloads
    bool operator == (const Line& line) const;
    // Returns true if both lines have equal lengths

    bool operator != (const Line& line) const;
    // Returns the logical NOT of the == comparison

    bool operator < (const Line& line) const;
    // Returns true if the lines length is greater than this line instance

    bool operator > (const Line& line) const;
    // Returns the logical NOT of the < comparison

private:

    Point m_point1; - A Cartesian point
    Point m_point2; - A Cartesian point

    static const double UNDEFINED; - Represents an UNDEFINED slope, defined as
                                     numeric limit of the double data type


* Author: Alexander DuPree

* Compiler: GNU GCC 5.4.0

* Date: 2018 - 05 - 17
*******************************************************************************/

#ifndef LINE_H
#define LINE_H

#include <exception>
#include <limits>
#include <cmath>
#include "point.h"

class Line
{
public:

    // Constructors
    Line();

    Line(const Point& point1, const Point& point2);

    Line(const int& x1, const int& y1, const int& x2, const int& y2);

    // Inspectors
    const Point& point1() const;
    const Point& point2() const;

    // Mutators
    Line* point1(const Point& point);
    Line* point2(const Point& point);

    Line* point1(const int& x, const int& y);
    Line* point2(const int& x, const int& y);

    // Member functions
    double slope() const;
    double length() const;


    // Operator Overloads
    bool operator == (const Line& line) const;
    bool operator != (const Line& line) const;
    bool operator < (const Line& line) const;
    bool operator > (const Line& line) const;

private:

    Point m_point1;
    Point m_point2;

    static const double UNDEFINED;

};

#endif // LINE_H
