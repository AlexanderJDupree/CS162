/*******************************************************************************
* File: triangle.h

* Description:

* Attributes and Methods:
public:

    - Constructors
    Triangle();
    // Precondition:
    // Postcondition: Instantiates an isocecles triangle object that occupies
                      the space (0,0)(0,1)(1,0)

    Triangle(int x1, int y1, int x2, int y2, int x3, int y3);
    // Preconditions:
    // Postcondition: instantiates a triangle object that occupies the points
                      provided, constructs lines to connect the points

    Triangle(const Point& pointA, const Point& pointB, const Point& pointC);
    // Preconditions:
    // Postcondition: instantiates a triangle object that occupies the points
                      provided,. constructs lines to connect the points


    - Inspectors
    const Point& getPoint1() const;
    // Postcondition: returns a const reference to Point 1

    const Point& getPoint2() const;
    // Postcondition: returns a const reference to Point 2

    const Point& getPoint3() const;
    // Postcondition: returns a const reference to Point 3

    const Line& getSide1() const;
    // Postconditions: returns a const reference to side 1

    const Line& getSide2() const;
    // Postconditions: returns a const reference to side 2

    const Line& getSide3() const;
    // Postconditions: returns a const reference to side 3

    - Mutators
    Triangle* setPoint1(const int& x, const int& y);
    // Preconditions: a valid integer reference
    // Postcondition: assigns point 1's members the values of x and y.
                      reconstructs the lines associated with the triangle

    Triangle* setPoint2(const int& x, const int& y);
    // Preconditions: a valid integer reference
    // Postcondition: assigns point 2's members the values of x and y.
                      reconstructs the lines associated with the triangle
    Triangle* setPoint3(const int& x, const int& y);
    // Preconditions: a valid integer reference
    // Postcondition: assigns point 3's members the values of x and y.
                      reconstructs the lines associated with the triangle

    - Member functions
    bool rightTriangle();
    // Postconditions: uses pythagoerans theorum to determine if the triangle
                       is a right triangle. Returns true if that is the case


    // Operator Overloads
    bool operator == (const Triangle& triangle) const;
    // Postcondition: Compares the sides of the triangles against itself,
                      returns true if the triangle is congruent
    bool operator != (const Triangle& triangle) const;
    // Postcondition: calls the == operator to conduct comparison. Returns the
                      logical NOT of the comparison

private:

    Point point1; - A Cartesian point representing a vertex of the triangle
    Point point2; - A Cartesian point representing a vertex of the triangle
    Point point3; - A Cartesian point representing a vertex of the triangle

    Line side1; - Represents the line connecting point1 and point2
    Line side2; - Represents the line connecting point2 and point3
    Line side3; - Represents the line connecting point3 and point1

    // Sub-routine
    void adjustLines();
    Postcondition: Reconnects the lines to their respective points

* Author: Alexander DuPree

* Date: 2018 - 05 - 21
*******************************************************************************/

#ifndef TRIANGLE_H
#define TRIANGLE_H

#include <exception>
#include <algorithm>
#include <vector>
#include "line.h"


class Triangle
{
public:

    Triangle();

    Triangle(int x1, int y1, int x2, int y2, int x3, int y3);

    Triangle(const Point& pointA, const Point& pointB, const Point& pointC);

    // Accessors
    const Point& getPoint1() const;
    const Point& getPoint2() const;
    const Point& getPoint3() const;

    const Line& getSide1() const;
    const Line& getSide2() const;
    const Line& getSide3() const;

    // Mutators
    Triangle* setPoint1(const int& x, const int& y);
    Triangle* setPoint2(const int& x, const int& y);
    Triangle* setPoint3(const int& x, const int& y);

    // Member functions
    bool rightTriangle();

    // Operator Overloads
    bool operator == (const Triangle& triangle) const;
    bool operator != (const Triangle& triangle) const;

private:

    Point point1;
    Point point2;
    Point point3;

    Line side1;
    Line side2;
    Line side3;

    // Sub-routine
    void adjustLines();

};

#endif // TRIANGLE_H
